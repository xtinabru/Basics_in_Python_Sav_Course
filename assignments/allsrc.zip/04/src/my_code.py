# -*- coding: utf-8 -*-
"""
04

Ask name, height [m], and weight [kg] of person. Use variables named as name, height 
,and weight. Compute

bmi = weight/height^2

and save the value in variable bmi.

Print bmi with two decimals. See example below:


Give your name: Jussi Juonio
Give height in meters: 1.81
Give weight in kgs: 104

Your name is Jussi Juonio, and you are 1.81m tall, and your weight is 104.0 kg.
Your bmi is 31.75
"""


